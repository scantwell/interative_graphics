This assignment consists of one program.
        - a3


a3 program implements the following features:
		- Double Buffering
		- Main window squares
		- Sub Window
		- Sub Window menu (right on sub window to use.) changes the background color of the subwindow.
		- Second window which includes a triangle and a circle
		- Second window input with key strokes, supported input to change color of objects
		'r' - red, 'g' - green, 'b' - blue, 'y' - yellow, 'o' - orange, 'p' - purple, 'w' - white
		- Animated square and triangle
		- Main menu - (right click to use) which includes functionality to change the color of the rotating squares and starting/stopping animations on both windows.
		- Adding circles to the main window is possible.

		Notes: I was unable to implement the 'breathing' functionality for the circles because I could not get Scale() function to work.\n Enjoy."<< std::endl;

How to Run:

 make
        To compile all of source files

 make run
        To run the a3 program.

 make clean
        Cleans all artifacts.
