This assignment consists of one program.
        - a9

Features:
	-3d texture implemented by calculating stripes down the object and adding noise based on the Normal and Eye position.
	- Allows for the step (number of stripes) to be changed programatically.	-2d texture is loaded on the beizer code and is implemented in the phong fragment shader.

How to Run:

 make
        To compile all of source files

 make run-a6
        To run a6 program.

make run-a7
	To run a7 program.

 make clean
        Cleans all artifacts.
